//
//  ProductListViewModel.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//



import Foundation
import UIKit
protocol HomeProtocol {
    
    func didFinishGettingData()
    
}

class ProductListViewModel{
    private var productListService: ProductsServiceProtocol
    var delegate: HomeProtocol?
    var reloadTableView: (() -> Void)?
    
    var productLists : ProductsList?
    var categoryList = [Values]()
    var bannerList = [Values]()
    var products = [Values]()
    
    init(productListService: ProductsServiceProtocol = ProductService()) {
        self.productListService = productListService
    }
    
    func getProductList() {
        productListService.getProducts { success, model, error in
            if success, let productLists = model {
                self.fetchData(productLists: productLists)
            } else {
                print(error!)
            }
        }
    }
    
    func fetchData(productLists: ProductsList) {
        self.productLists = productLists // Cache
        
        self.assignCategoryData(data: productLists.homeData![0].values! ?? [Values]())
        self.assignBannerData(data: productLists.homeData![1].values! ?? [Values]())
        self.assignProductData(data: productLists.homeData![2].values! ?? [Values]())
        self.delegate?.didFinishGettingData()
        
    }
    func assignCategoryData(data: [Values]) {
        self.categoryList = data
    }
    func assignBannerData(data: [Values]) {
        self.bannerList = data
    }
    func assignProductData(data: [Values]) {
        self.products = data
    }
    func getNumberOfCategory() -> Int {
        return categoryList.count
    }
    
    
    
}
