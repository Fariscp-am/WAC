//
//  BannersTableViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class BannersTableViewCell: UITableViewCell {
    
    @IBOutlet weak var bannerCollectionView: UICollectionView!
    var bannerList : [Values] = []
    override func awakeFromNib() {
        super.awakeFromNib()
        
        bannerCollectionView.delegate = self
        bannerCollectionView.dataSource = self
        bannerCollectionView.register(UINib.init(nibName: "BannersCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "BannersCollectionViewCell")
    }
    func getBanner(banner:[Values]){
        self.bannerList = banner
        DispatchQueue.main.async {
            self.bannerCollectionView.reloadData()
        }
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
extension BannersTableViewCell: UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bannerList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BannersCollectionViewCell", for: indexPath) as! BannersCollectionViewCell
        let banner = bannerList[indexPath.row]
        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:banner.banner_url ?? "")!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    cell.imgBanner.image = image
                }
            }
            catch {
                print("Error")
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let height = bannerCollectionView.frame.size.height
        let width = bannerCollectionView.frame.size.width
        return CGSize(width: width - 30 , height: height)
    }
    
    
}
