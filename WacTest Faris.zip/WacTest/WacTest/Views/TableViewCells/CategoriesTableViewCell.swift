//
//  CategoriesTableViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class CategoriesTableViewCell: UITableViewCell/*, HomeProtocol */{
    
    @IBOutlet weak var categoriesCollectionView: UICollectionView!
    
    //var viewModel = ProductListViewModel()
    var numberOfCategory : Int = 0
    var categoryList : [Values] = []
    var colorArray  = ["lightRed","lightPurple","lightPink","lightGray","lightYellow"]
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        categoriesCollectionView.delegate = self
        categoriesCollectionView.dataSource = self
        categoriesCollectionView.register(UINib.init(nibName: "CategoriesCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "CategoriesCollectionViewCell")
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
    }
    func getCategory(category:[Values]){
        self.categoryList = category
        self.numberOfCategory = category.count
        DispatchQueue.main.async {
            self.categoriesCollectionView.reloadData()
        }
        
    }
    
}
extension CategoriesTableViewCell: UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoriesCollectionViewCell", for: indexPath) as! CategoriesCollectionViewCell
        let categoryItem = categoryList[indexPath.row]
        
        cell.lblCategoryName.text = categoryItem.name
        DispatchQueue.main.async {
            cell.bgView.backgroundColor = UIColor(named: self.colorArray[indexPath.row])
        }
        
        let url = URL(string:categoryItem.image_url ?? "")
        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:categoryItem.image_url ?? "")!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    cell.imgCategories.image = image
                }
            }
            catch {
                print("Error")
            }
        }
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height = categoriesCollectionView.frame.size.height
        let width = categoriesCollectionView.frame.size.width
        return CGSize(width: width/3.5, height: height)
    }
    
    
    
}


