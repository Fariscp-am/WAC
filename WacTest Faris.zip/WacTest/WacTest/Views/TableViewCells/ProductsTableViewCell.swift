//
//  ProductsTableViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class ProductsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var ProductsCollectionView: UICollectionView!
    var productsList : [Values] = []
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func getProducts(products:[Values]){
        self.productsList = products
        DispatchQueue.main.async {
            self.ProductsCollectionView.reloadData()
        }
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
        ProductsCollectionView.delegate = self
        ProductsCollectionView.dataSource = self
        ProductsCollectionView.register(UINib.init(nibName: "ProductsCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ProductsCollectionViewCell")
    }
    
}
extension ProductsTableViewCell: UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productsList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductsCollectionViewCell", for: indexPath) as! ProductsCollectionViewCell
        let product = productsList[indexPath.row]
        if product.is_express!{
            cell.imgExpressProduct.isHidden = false
        }else{
            cell.imgExpressProduct.isHidden = true
        }
        if product.offer! > 0{
            cell.offerView.isHidden = false
            cell.lblDiscount.text = "  \(String(product.offer!))% OFF"
        }else{
            cell.offerView.isHidden = true
        }
        if product.offer_price! == product.actual_price!{
            cell.lblActualPrice.isHidden = true
            cell.lblOfferPrice.text = product.offer_price
        }else{
            cell.lblActualPrice.isHidden = false
            cell.lblActualPrice.text = product.actual_price
            cell.lblOfferPrice.text = product.offer_price
            
        }
        cell.lblProductName.text = product.name
        DispatchQueue.global(qos: .background).async {
            do
            {
                let data = try Data.init(contentsOf: URL.init(string:product.image ?? "")!)
                DispatchQueue.main.async {
                    let image: UIImage = UIImage(data: data)!
                    cell.imgProduct.image = image
                }
            }
            catch {
                print("Error")
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let height = ProductsCollectionView.frame.size.height
        let width = ProductsCollectionView.frame.size.width
        return CGSize(width: width * 0.45 , height: height)
    }
    
    
}
