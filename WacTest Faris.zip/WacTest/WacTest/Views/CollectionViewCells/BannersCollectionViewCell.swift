//
//  BannersCollectionViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class BannersCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgBanner: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
}
