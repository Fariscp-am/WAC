//
//  CategoriesCollectionViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class CategoriesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var lblCategoryName: UILabel!
    @IBOutlet weak var imgCategories: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

}
