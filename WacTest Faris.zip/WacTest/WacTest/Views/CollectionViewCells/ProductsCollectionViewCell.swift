//
//  ProductsCollectionViewCell.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class ProductsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var backGroundView: UIView!
    @IBOutlet weak var offerView: UIView!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var lblProductName: UILabel!
    @IBOutlet weak var lblOfferPrice: UILabel!
    @IBOutlet weak var lblActualPrice: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var imgExpressProduct: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let attributedText = NSAttributedString(
            string: "Label Text",
            attributes: [.strikethroughStyle: NSUnderlineStyle.single.rawValue]
        )
        lblActualPrice.attributedText = attributedText
    }
    
}
