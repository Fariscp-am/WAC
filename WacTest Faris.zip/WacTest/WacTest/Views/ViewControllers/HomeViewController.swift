//
//  HomeViewController.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import UIKit

class HomeViewController: UIViewController, HomeProtocol {
    func didFinishGettingData() {
        DispatchQueue.main.async {
            self.tableViewHome.reloadData()
        }
        
    }
    
    
    @IBOutlet weak var tableViewHome: UITableView!
    var viewModel = ProductListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableViewHome.dataSource = self
        tableViewHome.delegate = self
        viewModel.delegate = self
        registerNib()
        initViewModel()
    }
    func registerNib() {
        
        tableViewHome.register(UINib.init(nibName: "CategoriesTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "CategoriesTableViewCell")
        tableViewHome.register(UINib.init(nibName: "BannersTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "BannersTableViewCell")
        tableViewHome.register(UINib.init(nibName: "ProductsTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "ProductsTableViewCell")
    }
    func initViewModel() {
        
        viewModel.getProductList()
    }
}
extension HomeViewController : UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        if section == 1 {
            return 1
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CategoriesTableViewCell", for: indexPath) as! CategoriesTableViewCell
            cell.getCategory(category: viewModel.categoryList)
            return cell
        }
        if indexPath.section == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "BannersTableViewCell", for: indexPath) as! BannersTableViewCell
            cell.getBanner(banner: viewModel.bannerList)
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell", for: indexPath) as! ProductsTableViewCell
        cell.getProducts(products: viewModel.products)
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            return 135
        }
        if indexPath.section == 1{
            return 180
        }
        return 350
    }
}
