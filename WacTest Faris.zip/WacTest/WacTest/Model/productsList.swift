//
//  productsList.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import Foundation

typealias ProductsLists = [ProductsList]


struct ProductsList: Codable {
    let status : Bool?
    let homeData : [HomeData]?
    
    enum CodingKeys: String, CodingKey {
        
        case status = "status"
        case homeData = "homeData"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(Bool.self, forKey: .status)
        homeData = try values.decodeIfPresent([HomeData].self, forKey: .homeData)
    }
    
}


struct HomeData : Codable {
    let type : String?
    let values : [Values]?
    
    enum CodingKeys: String, CodingKey {
        
        case type = "type"
        case values = "values"
    }
    
    init(from decoder: Decoder) throws {
        var valuess = try decoder.container(keyedBy: CodingKeys.self)
        type = try valuess.decodeIfPresent(String.self, forKey: .type)
        values = try valuess.decodeIfPresent([Values].self, forKey: .values)
    }
    
}
struct Values : Codable {
    let id,offer : Int?
    let name : String?
    let image_url,image,actual_price,offer_price,banner_url : String?
    let is_express : Bool?
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case name = "name"
        case image_url = "image_url"
        case offer = "offer"
        case image = "image"
        case actual_price = "actual_price"
        case offer_price = "offer_price"
        case banner_url = "banner_url"
        case is_express = "is_express"
    }
    
    init(from decoder: Decoder) throws {
        let valuess = try decoder.container(keyedBy: CodingKeys.self)
        id = try valuess.decodeIfPresent(Int.self, forKey: .id)
        name = try valuess.decodeIfPresent(String.self, forKey: .name)
        image_url = try valuess.decodeIfPresent(String.self, forKey: .image_url)
        offer = try valuess.decodeIfPresent(Int.self, forKey: .offer)
        image = try valuess.decodeIfPresent(String.self, forKey: .image)
        actual_price = try valuess.decodeIfPresent(String.self, forKey: .actual_price)
        offer_price = try valuess.decodeIfPresent(String.self, forKey: .offer_price)
        banner_url = try valuess.decodeIfPresent(String.self, forKey: .banner_url)
        is_express = try valuess.decodeIfPresent(Bool.self, forKey: .is_express)
    }
    
}

