//
//  ProductService.swift
//  WacTest
//
//  Created by Faris on 19/02/23.
//

import Foundation
protocol ProductsServiceProtocol {
    func getProducts(completion: @escaping (_ success: Bool, _ results: ProductsList?, _ error: String?) -> ())
}

class ProductService: ProductsServiceProtocol {
    func getProducts(completion: @escaping (Bool, ProductsList?, String?) -> ()) {
        HttpRequestHelper().GET(url: "https://run.mocky.io/v3/69ad3ec2-f663-453c-868b-513402e515f0", httpHeader: .application_json) { success, data in
            if success {
                do {
                    let jsonDecoder = JSONDecoder()
                    let responseModel = try jsonDecoder.decode(ProductsList.self, from: data!)
                    completion(true, responseModel, nil)
                } catch {
                    completion(false, nil, "Error: Trying to parse Employees to model")
                }
            } else {
                completion(false, nil, "Error: Employees GET Request failed")
            }
        }
    }
}
